Command line help
-----------------

.. program-output:: py2pack -h
